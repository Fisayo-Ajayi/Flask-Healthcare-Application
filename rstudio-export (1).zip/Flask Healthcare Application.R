# Install required libraries if not already installed
if (!require(ggplot2)) install.packages("ggplot2", dependencies = TRUE)
if (!require(dplyr)) install.packages("dplyr", dependencies = TRUE)
if (!require(tidyr)) install.packages("tidyr", dependencies = TRUE)

# Load the libraries
library(ggplot2)
library(dplyr)
library(tidyr)


# Load the survey data
csv_file <- "survey_data.csv"
df <- read.csv(csv_file)


# Display basic information about the data
print(str(df))  # Structure of the dataset
print(summary(df))  # Summary statistics for numerical data


# Visualization 1: Age vs. Total Income (Barplot)
ggplot(df, aes(x = age, y = income)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  labs(x = "Age", y = "Income", title = "Income Distribution by Age") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


# Visualization 2: Gender Distribution Across Income Categories (Boxplot)
ggplot(df, aes(x = gender, y = income, fill = gender)) +
  geom_boxplot() +
  labs(title = "Income Distribution by Gender") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


# Export the visualizations for use in a PowerPoint presentation
ggsave("income_by_age.png")
ggsave("income_by_gender.png")

cat("Analysis completed. Charts have been saved.\n")
